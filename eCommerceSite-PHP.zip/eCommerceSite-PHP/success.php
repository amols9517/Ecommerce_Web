<?php
require_once('header.php');
?>

<div class="success-page">
    <h2>OTP Verification Successful</h2>
    <p>Congratulations! Your OTP has been successfully verified.</p>
    <p>Perform any additional actions or display a success message here.</p>
</div>

<?php require_once('footer.php'); ?>
